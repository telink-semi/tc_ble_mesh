//
//  YZDisplayTitleLabel.h
//  BuDeJie
//
//  Created by yz on 15/12/4.
//  Copyright © 2015年 yz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YZDisplayTitleLabel : UILabel

@property (nonatomic, assign) CGFloat progress;

@property (nonatomic, strong) UIColor *fillColor;

@end
