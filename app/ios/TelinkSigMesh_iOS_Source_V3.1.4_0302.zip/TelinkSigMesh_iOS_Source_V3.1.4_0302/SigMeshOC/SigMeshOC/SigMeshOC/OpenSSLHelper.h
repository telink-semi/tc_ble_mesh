/********************************************************************************************************
 * @file     OpenSSLHelper.h
 *
 * @brief    for TLSR chips
 *
 * @author     telink
 * @date     Sep. 30, 2010
 *
 * @par      Copyright (c) 2010, Telink Semiconductor (Shanghai) Co., Ltd.
 *           All rights reserved.
 *
 *             The information contained herein is confidential and proprietary property of Telink
 *              Semiconductor (Shanghai) Co., Ltd. and is available under the terms
 *             of Commercial License Agreement between Telink Semiconductor (Shanghai)
 *             Co., Ltd. and the licensee in separate contract or the terms described here-in.
 *           This heading MUST NOT be removed from this file.
 *
 *              Licensees are granted free, non-transferable use of the information in this
 *             file under Mutual Non-Disclosure Agreement. NO WARRENTY of ANY KIND is provided.
 *
 *******************************************************************************************************/
//
//  OpenSSLHelper.h
//  SigMeshOC
//
//  Created by Liangjiazhi on 2019/8/8.
//  Copyright © 2019年 Telink. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OpenSSLHelper : NSObject

+ (OpenSSLHelper *)share;

/// Generates 128-bit random data.
- (NSData *)generateRandom;

/// Calculates salt over given data.
/// @param someData A non-zero length octet array or ASCII encoded string.
- (NSData *)calculateSalt:(NSData *)someData;

/// Calculates Cipher-based Message Authentication Code (CMAC) that uses
/// AES-128 as the block cipher function, also known as AES-CMAC.
/// @param someData Data to be authenticated.
/// @param key The 128-bit key.
/// @return The 128-bit authentication code (MAC).
- (NSData *)calculateCMAC:(NSData *)someData andKey:(NSData *)key;

/// RFC3610 defines teh AES Counted with CBC-MAC (CCM).
/// This method generates ciphertext and MIC (Message Integrity Check).
/// @param someData The data to be encrypted and authenticated, also known as plaintext.
/// @param key The 128-bit key.
/// @param nonce A 104-bit nonce.
/// @param micSize Length of the MIC to be generated, in bytes.
/// @return Encrypted data concatenated with MIC of given size.
- (NSData *)calculateCCM:(NSData *)someData withKey:(NSData *)key nonce:(NSData *)nonce andMICSize:(UInt8)micSize;

/// Decrypts data encrypted with CCM.
/// @param someData Encrypted data.
/// @param key The 128-bit key.
/// @param nonce A 104-bit nonce.
/// @param mic Message Integrity Check data.
/// @return Decrypted data, if decryption is successful and MIC is valid, otherwise `nil`.
- (NSData *)calculateDecryptedCCM:(NSData *)someData withKey:(NSData *)key nonce:(NSData *)nonce andMIC:(NSData *)mic;

/// Obfuscates given data by XORing it with PECB, which is caluclated by encrypting
/// Privacy Plaintext (encrypted data (used as Privacy Random) and IV Index)
/// using the given key.
/// @param data The data to obfuscate.
/// @param privacyRandom Data used as Privacy Random.
/// @param ivIndex The current IV Index value.
/// @param privacyKey The 128-bit Privacy Key.
/// @return Obfuscated data of the same size as input data.
- (NSData *)obfuscate:(NSData *)data usingPrivacyRandom:(NSData *)privacyRandom ivIndex:(UInt32)ivIndex andPrivacyKey:(NSData *)privacyKey;

/// Deobfuscates given data. This method reverses the obfuscation done by method above.
///
/// @param data The obfuscated data.
/// @param ivIndex The current IV Index value.
/// @param privacyKey The 128-bit Privacy Key.
/// @return Deobfuscated data of the same size as input data.
- (NSData *)deobfuscate:(NSData *)data ivIndex:(UInt32)ivIndex privacyKey:(NSData *)privacyKey;

// MARK: - Helpers

/// THe network key material derivation function k1 is used to generate
/// instances of Identity Key and Beacon Key.
///
/// The definition of this derivation function makes use of the MAC function
/// AES-CMAC(T) with 128-bit key T.
/// @param N is 0 or more octets.
/// @param salt is 128 bits.
/// @param P is 0 or more octets.
/// @return 128-bit key.
- (NSData *)calculateK1WithN:(NSData *)N salt:(NSData *)salt andP:(NSData *)P;

/// The network key material derivation function k2 is used to generate
/// instances of Encryption Key, Privacy Key and NID for use as Master and
/// Private Low Power node communication. This method returns 33 byte data.
///
/// The definition of this derivation function makes use of the MAC function
/// AES-CMAC(T) with 128-bit key T.
/// @param N 128-bit key.
/// @param P 1 or more octets.
/// @return NID (7 bits), Encryption Key (128 bits) and Privacy Key (128 bits).
- (NSData *)calculateK2WithN:(NSData *)N andP:(NSData *)P;

/// The derivation function k3 us used to generate a public value of 64 bits
/// derived from a private key.
///
/// The definition of this derivation function makes use of the MAC function
/// AES-CMAC(T) with 128-bit key T.
/// @param N 128-bit key.
/// @return 64 bits of a public value derived from the key.
- (NSData *)calculateK3WithN:(NSData *)N;

/// The derivation function k4 us used to generate a public value of 6 bits
/// derived from a private key.
///
/// The definition of this derivation function makes use of the MAC function
/// AES-CMAC(T) with 128-bit key T.
/// @param N 128-bit key.
/// @return UInt8 with 6 LSB bits of a public value derived from the key.
- (UInt8)calculateK4WithN:(NSData *)N;

/// Encrypts given data using the key.
/// @param someData Data to be encrypted.
/// @param key The 128-bit key.
/// @return A byte array of encrypted data using the key. The size of the returned
///         array is equal to the size of input data.
- (NSData *)calculateEvalueWithData:(NSData *)someData andKey:(NSData *)key;

- (UInt8)aesAttDecryptionPacketOnlineStatusWithNetworkBeaconKey:(UInt8 *)key iv:(UInt8 *)iv ivLen:(UInt8)ivLen mic:(UInt8 *)mic micLen:(UInt8)micLen ps:(UInt8 *)ps psLen:(int)psLen;

@end
