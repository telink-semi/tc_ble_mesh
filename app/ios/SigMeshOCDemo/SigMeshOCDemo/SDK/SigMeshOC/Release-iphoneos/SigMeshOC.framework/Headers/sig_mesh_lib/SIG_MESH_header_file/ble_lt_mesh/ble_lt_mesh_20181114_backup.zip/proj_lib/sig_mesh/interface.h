/********************************************************************************************************
 * @file     interface.h 
 *
 * @brief    for TLSR chips
 *
 * @author	 telink
 * @date     Sep. 30, 2010
 *
 * @par      Copyright (c) 2010, Telink Semiconductor (Shanghai) Co., Ltd.
 *           All rights reserved.
 *           
 *			 The information contained herein is confidential and proprietary property of Telink 
 * 		     Semiconductor (Shanghai) Co., Ltd. and is available under the terms 
 *			 of Commercial License Agreement between Telink Semiconductor (Shanghai) 
 *			 Co., Ltd. and the licensee in separate contract or the terms described here-in. 
 *           This heading MUST NOT be removed from this file.
 *
 * 			 Licensees are granted free, non-transferable use of the information in this 
 *			 file under Mutual Non-Disclosure Agreement. NO WARRENTY of ANY KIND is provided. 
 *           
 *******************************************************************************************************/
// gerneral defination 
#include "../../../reference/tl_bulk/lib_file/Gatt_provision.h"
#include "../../proj_lib/ble/ll/ll.h"
#include "../../proj_lib/ble/blt_config.h"
#include "../../vendor/common/user_config.h"
#include "app_mesh.h"
#include "../../proj_lib/mesh_crypto/mesh_crypto.h"
#include "../../proj_lib/pm.h"
#include "app_proxy.h"
#include "app_health.h"


//output function 
// sig-mesh lib interface part 
unsigned int get_lib_version();
// pack one part function 
unsigned char test_pragma_pack();
// main_loop part can call the function 
void mesh_loop_process();
// need to init the clock_time
void  master_clock_init();
// main_loop part and user_init
void mesh_init_all();
// interface to dispatch the proxy packet part  
// merge the provision packet into one packet 
u8 provision_dispatch_direct(u8 *p,u8 len,u8* proxy_buf,u16* p_proxy_len);
// interface to dispatch the provision part 
//provision part dispatch 
void gatt_rcv_pro_pkt_dispatch(u8 *p ,u8 len );
// send pkts interfaces 
// thread main_loop process 
void Thread_main_process();
void push_notify_into_fifo(u8 *p ,u32 len );
void flash_erase_512K();
extern mesh_cfg_cmd_sub_set_par_t mesh_cfg_cmd_sub_set_par;
int mesh_construct_adv_bear_with_nw(u8 *bear, u8 *nw, u8 len_nw);

void write_no_rsps_pkts(u8 *p,u16 len,u16 handle,u8 msg_type);
// set provision data 
u8 set_app_key_pro_data(u8 *p_dat,u8 len);
// start send provision invite cmd 
void start_provision_invite();
// init the provision_mag struct init ,return 1 means success ,return 0 means fail 
unsigned char  get_provision_state();
// Receive part interface 
int app_event_handler_adv(u8 *p_payload, int src_type, u8 need_proxy_and_trans_par_val);

unsigned int  clock_time_exceed(unsigned int ref, unsigned int span_us);
unsigned int  clock_time();

//-----------
void mesh_tx_reliable_stop_report(u16 op, u32 rsp_max, u32 rsp_cnt);

/************************** mesh_provision_par_set_dir **************************
function : set the provisioner's internal node provision data  
para:
	typedef struct{
		u8  net_work_key[16];
		u16  key_index;
		u8  flags;
		u8  iv_index[4];
		u16  unicast_address;
	}provison_net_info_str;
ret: 0  means OK 
	-1 or other value means err
****************************************************************************/	
int mesh_provision_par_set_dir(u8 *prov_par);

/************************** check_pkt_is_unprovision_beacon **************************
function : check the pkt is unprovision beacon or not    
para:
	dat: the pointer of the rcv pkt part 
ret: 0  means OK 
	-1 or other value means err
****************************************************************************/
int check_pkt_is_unprovision_beacon(u8 *dat);


// mesh_key part for debug 
int cfg_cmd_reset_node(u16 node_adr);

int mesh_proxy_set_filter_init(u16 self_adr);

void mesh_kc_cfgcl_mode_para_set(u16 apk_idx,u8 *p_appkey,u16 unicast,u16 nk_idx);


void master_terminate_ble_callback();

void set_gatt_pro_cloud_en(u8 en);
void set_random_enable(u8 en);
int gatt_get_node_ele_cnt(u16 unicast ,u8 *p_ele);


/*******************json_get_node_cps_info****************************
get the composition data of the node ,and it can call when appkey bind endcallback 
unicast_adr: the input para ,the node's unicast adr part 
p_node: the pointer of the composition data of the node part 
**************************************************************/

u8 json_get_node_cps_info(u16 unicast_adr,VC_node_info_t *p_node);


/*************************input function *************************
**************************************************************/
//should be realize by the app
// SendPkt interface,need to realize by the master part 
extern unsigned char SendPkt(unsigned short handle,unsigned char *p ,unsigned char  len);
// the recv part of the VC part 
extern int OnAppendLog_vs(unsigned char *p, int len);
// time part function 
extern unsigned int  clock_time_vc_hw();
// flash operation part 
extern void flash_write_page(u32 addr, u32 len, const u8 *buf);
extern void flash_read_page(u32 addr, u32 len, u8 *buf);
extern void RefreshStatusNotifyByHw(unsigned char *p, int len);

extern int LogMsgModuleDlg_and_buf(u8 *pbuf,int len,char *log_str,char *format, va_list list);

extern int App_key_bind_end_callback(u8 event);
//printf interface 
/*
typedef enum{
	PROV_NORMAL_RET =0,
	PROV_TIMEOUT_RET =1,
};
*/
extern void provision_end_callback(u8 reason);

extern void mesh_proxy_master_terminate_cmd();

extern int mesh_set_prov_cloud_para(u8 *p_pid,u8 *p_mac);
/**************************mesh_sec_prov_cloud_comfirm***************************
function : use the para of the provision comfirm  key and the provision random to caculate the  comfirm value
para:
	p_comfirm: the result of the comfirm value (16 bytes) (out)
	p_comfirm_key: the pointer of the comfirm key (16 bytes)(in)
	pro_random: the pointer of the random value (16 bytes)(in)
ret: 1  means OK 
	not use the return 
notice: it should wait the result of the comfirm value before the function return ,or the flow will be error
	
******************************************************************************/
extern int mesh_sec_prov_cloud_comfirm(u8* p_comfirm,u8 *p_comfirm_key,u8 *pro_random);
/**************************mesh_cloud_dev_comfirm_check***************************
function : use the para of the comfirm key and the dev random to calculate the device random ,and compare with the random
		value receive from the device .
para:
	p_comfirm_key: the pointer of the comfirm key (16 bytes)(in)
	p_dev_random: the device random send by the device(16 bytes)(in)
	pro_random: the pointer of the random value (16 bytes)(in)
ret: 1  means OK 
	0  will terminate the gatt connection 
notice: it should wait the result of the comfirm value before the function return ,or the flow will be error
	
******************************************************************************/
extern int mesh_cloud_dev_comfirm_check(u8 *p_comfirm_key,u8* p_dev_random,
								u8*p_dev_comfirm);
/**************************gatt_provision_net_info_callback***************************
function : when the provision enter the provision data send ,it will cause this callback ,will used to set 
		the provision data para ,and we will use the gatt_provision_net_info_callback to set .
para:
ret: void
notice: it should wait the result of the comfirm value before the function return ,or the flow will be error
	
******************************************************************************/
extern void gatt_provision_net_info_callback();
/**************************set_gatt_provision_net_info***************************
function : set the provision parameters ,and use in the gatt_provision_net_info_callback
para:
	p_netkey: the pointer of the netkey (16 bytes )(in)
	p_key_index: the pointer of the key index (2 bytes)(in)
	p_flag: the pointer of the flags about the netkey (1 bytes)(in)
	p_ivi: the pointer of the ivi index (4 bytes)(in)
	p_unicast: the pointer of the unicast address(2 bytes)(in)
ret: void
notice: it should wait the result of the comfirm value before the function return ,or the flow will be error
******************************************************************************/
extern void set_gatt_provision_net_info(u8 p_netkey[16],u16*p_key_index,u8*p_flag,u8 p_ivi[4],u16*p_unicast);

extern u8 model_need_key_bind_whitelist(u16 *key_bind_list_buf,u8 *p_list_cnt,u8 max_cnt);



