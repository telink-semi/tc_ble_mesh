/********************************************************************************************************
 * @file     clock.c 
 *
 * @brief    for TLSR chips
 *
 * @author	 telink
 * @date     Sep. 30, 2010
 *
 * @par      Copyright (c) 2010, Telink Semiconductor (Shanghai) Co., Ltd.
 *           All rights reserved.
 *           
 *			 The information contained herein is confidential and proprietary property of Telink 
 * 		     Semiconductor (Shanghai) Co., Ltd. and is available under the terms 
 *			 of Commercial License Agreement between Telink Semiconductor (Shanghai) 
 *			 Co., Ltd. and the licensee in separate contract or the terms described here-in. 
 *           This heading MUST NOT be removed from this file.
 *
 * 			 Licensees are granted free, non-transferable use of the information in this 
 *			 file under Mutual Non-Disclosure Agreement. NO WARRENTY of ANY KIND is provided. 
 *           
 *******************************************************************************************************/

#include "register.h"
#include "clock.h"
#include "irq.h"
#include "analog.h"

#if 0
void clock_init(SYS_CLK_TYPEDEF SYS_CLK)
{
    switch(SYS_CLK)
    {
    	case SYS_CLK_12M_Crystal:
    	    WRITE_REG8(0x66,0x44);
    	    WRITE_REG8(0x70,READ_REG8(0x70)&0xfe);
    		break;
    	case SYS_CLK_16M_Crystal:
    	    WRITE_REG8(0x66,0x43);
    	    WRITE_REG8(0x70,READ_REG8(0x70)&0xfe);
    		break;
    	case SYS_CLK_24M_Crystal:
    	    WRITE_REG8(0x66,0x42);
    	    WRITE_REG8(0x70,READ_REG8(0x70)&0xfe);
    		break;
    	case SYS_CLK_32M_Crystal:
    	    WRITE_REG8(0x66,0x60);
    	    WRITE_REG8(0x70,READ_REG8(0x70)&0xfe);
    		break;
    	case SYS_CLK_48M_Crystal:
    	    WRITE_REG8(0x66,0x20);
    	    WRITE_REG8(0x70,READ_REG8(0x70)&0xfe);
    		break;
    	case SYS_CLK_24M_RC:
    	    WRITE_REG8(0x66,0x00);
    	    WRITE_REG8(0x70,READ_REG8(0x70)&0xfe);
    		break;
    	default:
    	    WRITE_REG8(0x66,0x00);
    	    WRITE_REG8(0x70,READ_REG8(0x70)&0xfe);
    		break;
    }
}
#endif


_attribute_ram_code_ void sleep_us (unsigned long us)
{
	unsigned long t = clock_time();
	while(!clock_time_exceed(t, us)){
	}
}

#ifdef	USE_SYS_TICK_PER_US
u32		sys_tick_per_us = 16;
void set_tick_per_us (u32 t)
{
	sys_tick_per_us = t;
}
#else
void set_tick_per_us (u32 t)
{

}
#endif


